<?php
$pageTitle = 'Add Book';
require_once __DIR__ . '/includes/admin_header.php';

$errors = [];
$categories = db()->query('SELECT * FROM categories ORDER BY name')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $title = clean_input($_POST['title'] ?? '');
    $author = clean_input($_POST['author'] ?? '');
    $description = clean_input($_POST['description'] ?? '');
    $price = (float)($_POST['price'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);
    $categoryId = (int)($_POST['category_id'] ?? 0) ?: null;
    $isDigital = isset($_POST['is_digital']) ? 1 : 0;

    if ($title === '') $errors[] = 'Title is required.';
    if ($author === '') $errors[] = 'Author is required.';
    if ($price <= 0) $errors[] = 'Price must be greater than zero.';

    $coverName = null;
    $ebookName = null;

    if (!$errors) {
        try {
            $coverName = handle_upload('cover_image', UPLOAD_COVER_DIR, ['jpg','jpeg','png','webp']);
            if ($isDigital) {
                $ebookName = handle_upload('ebook_file', UPLOAD_BOOK_DIR, ['pdf','epub']);
            }
        } catch (RuntimeException $e) {
            $errors[] = $e->getMessage();
        }
    }

    if (!$errors) {
        $stmt = db()->prepare('INSERT INTO books (title, author, description, price, stock, category_id, cover_image, ebook_file, is_digital, uploaded_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([$title, $author, $description, $price, $isDigital ? 0 : $stock, $categoryId, $coverName, $ebookName, $isDigital, current_user()['id']]);
        flash('success', 'Book "' . $title . '" added successfully.');
        redirect('/admin/books_manage.php');
    }
}
?>
<h2>Add New Book</h2>
<?php foreach ($errors as $err): ?><div class="error-box"><?= e($err) ?></div><?php endforeach; ?>

<form method="post" action="" enctype="multipart/form-data" style="max-width:600px;">
  <?= csrf_field() ?>
  <label>Title</label>
  <input type="text" name="title" required value="<?= e($_POST['title'] ?? '') ?>">

  <label>Author</label>
  <input type="text" name="author" required value="<?= e($_POST['author'] ?? '') ?>">

  <label>Description</label>
  <textarea name="description"><?= e($_POST['description'] ?? '') ?></textarea>

  <label>Price (<?= CURRENCY ?>)</label>
  <input type="number" step="0.01" name="price" required value="<?= e($_POST['price'] ?? '') ?>">

  <label>Category</label>
  <select name="category_id">
    <option value="0">— None —</option>
    <?php foreach ($categories as $c): ?>
      <option value="<?= $c['id'] ?>"><?= e($c['name']) ?></option>
    <?php endforeach; ?>
  </select>

  <label><input type="checkbox" name="is_digital" id="is_digital" style="width:auto;display:inline-block;" onchange="document.getElementById('stock_field').style.display=this.checked?'none':'block';document.getElementById('ebook_field').style.display=this.checked?'block':'none';"> This is a digital eBook (no physical stock)</label>

  <div id="stock_field">
    <label>Stock Quantity</label>
    <input type="number" name="stock" value="<?= e($_POST['stock'] ?? 0) ?>">
  </div>

  <div id="ebook_field" style="display:none;">
    <label>eBook File (PDF or EPUB)</label>
    <input type="file" name="ebook_file" accept=".pdf,.epub">
  </div>

  <label>Cover Image (JPG, PNG, WEBP)</label>
  <input type="file" name="cover_image" accept=".jpg,.jpeg,.png,.webp">

  <div class="form-actions">
    <button type="submit" class="btn btn-primary">Save Book</button>
  </div>
</form>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
