<?php
$pageTitle = 'Orders';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_status') {
    verify_csrf();
    $orderId = (int)$_POST['order_id'];
    $status = $_POST['status'];
    $allowed = ['pending','paid','failed','shipped','completed','cancelled'];
    if (in_array($status, $allowed, true)) {
        db()->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute([$status, $orderId]);
        flash('success', 'Order #' . $orderId . ' updated to ' . $status . '.');
    }
    redirect('/admin/orders.php');
}

$orders = db()->query('SELECT o.*, u.full_name, u.email FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC')->fetchAll();
?>
<h2>All Orders</h2>
<?php if ($msg = flash('success')): ?><div class="success-box"><?= e($msg) ?></div><?php endif; ?>

<table>
  <thead><tr><th>#</th><th>Customer</th><th>Total</th><th>Method</th><th>Ref</th><th>Status</th><th>Date</th><th>Update</th></tr></thead>
  <tbody>
  <?php foreach ($orders as $o): ?>
    <tr>
      <td><?= (int)$o['id'] ?></td>
      <td><?= e($o['full_name']) ?><br><small style="color:#888;"><?= e($o['email']) ?></small></td>
      <td><?= format_money($o['total_amount']) ?></td>
      <td><?= e(strtoupper($o['payment_method'])) ?></td>
      <td style="font-size:.8rem;"><?= e($o['payment_reference'] ?? '—') ?></td>
      <td><span class="badge badge-<?= e($o['status']) ?>"><?= e(ucfirst($o['status'])) ?></span></td>
      <td><?= e(date('M j, Y', strtotime($o['created_at']))) ?></td>
      <td>
        <form method="post" style="display:flex;gap:6px;">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="update_status">
          <input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>">
          <select name="status">
            <?php foreach (['pending','paid','failed','shipped','completed','cancelled'] as $s): ?>
              <option value="<?= $s ?>" <?= $o['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
            <?php endforeach; ?>
          </select>
          <button type="submit" class="btn btn-primary btn-small">Save</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
