<?php
$pageTitle = 'Dashboard';
require_once __DIR__ . '/includes/admin_header.php';

$totalBooks = db()->query('SELECT COUNT(*) c FROM books')->fetch()['c'];
$totalUsers = db()->query("SELECT COUNT(*) c FROM users WHERE role='customer'")->fetch()['c'];
$totalOrders = db()->query('SELECT COUNT(*) c FROM orders')->fetch()['c'];
$totalRevenue = db()->query("SELECT COALESCE(SUM(total_amount),0) s FROM orders WHERE status IN ('paid','completed','shipped')")->fetch()['s'];
$lowStock = db()->query('SELECT * FROM books WHERE is_digital = 0 AND stock <= 5 ORDER BY stock ASC LIMIT 5')->fetchAll();
$recentOrders = db()->query('SELECT o.*, u.full_name FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 8')->fetchAll();
?>
<h2>Dashboard</h2>
<div class="stat-cards">
  <div class="stat-card"><div class="num"><?= (int)$totalBooks ?></div><div class="label">Total Books</div></div>
  <div class="stat-card"><div class="num"><?= (int)$totalUsers ?></div><div class="label">Registered Customers</div></div>
  <div class="stat-card"><div class="num"><?= (int)$totalOrders ?></div><div class="label">Total Orders</div></div>
  <div class="stat-card"><div class="num"><?= format_money($totalRevenue) ?></div><div class="label">Revenue (paid)</div></div>
</div>

<h3>Recent Orders</h3>
<table>
  <thead><tr><th>#</th><th>Customer</th><th>Total</th><th>Method</th><th>Status</th><th>Date</th></tr></thead>
  <tbody>
  <?php foreach ($recentOrders as $o): ?>
    <tr>
      <td><?= (int)$o['id'] ?></td>
      <td><?= e($o['full_name']) ?></td>
      <td><?= format_money($o['total_amount']) ?></td>
      <td><?= e(strtoupper($o['payment_method'])) ?></td>
      <td><span class="badge badge-<?= e($o['status']) ?>"><?= e(ucfirst($o['status'])) ?></span></td>
      <td><?= e(date('M j, Y', strtotime($o['created_at']))) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>

<?php if ($lowStock): ?>
<h3 style="margin-top:30px;">Low Stock Alerts</h3>
<table>
  <thead><tr><th>Title</th><th>Stock</th></tr></thead>
  <tbody>
  <?php foreach ($lowStock as $b): ?>
    <tr><td><?= e($b['title']) ?></td><td style="color:var(--danger);font-weight:700;"><?= (int)$b['stock'] ?></td></tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
