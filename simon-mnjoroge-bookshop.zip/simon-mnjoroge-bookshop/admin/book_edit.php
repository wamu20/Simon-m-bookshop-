<?php
$pageTitle = 'Edit Book';
require_once __DIR__ . '/includes/admin_header.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT * FROM books WHERE id = ?');
$stmt->execute([$id]);
$book = $stmt->fetch();

if (!$book) {
    echo '<h2>Book not found</h2>';
    require_once __DIR__ . '/includes/admin_footer.php';
    exit;
}

$errors = [];
$categories = db()->query('SELECT * FROM categories ORDER BY name')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $title = clean_input($_POST['title'] ?? '');
    $author = clean_input($_POST['author'] ?? '');
    $description = clean_input($_POST['description'] ?? '');
    $price = (float)($_POST['price'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);
    $categoryId = (int)($_POST['category_id'] ?? 0) ?: null;
    $isDigital = isset($_POST['is_digital']) ? 1 : 0;

    if ($title === '') $errors[] = 'Title is required.';
    if ($author === '') $errors[] = 'Author is required.';
    if ($price <= 0) $errors[] = 'Price must be greater than zero.';

    $coverName = $book['cover_image'];
    $ebookName = $book['ebook_file'];

    if (!$errors) {
        try {
            $newCover = handle_upload('cover_image', UPLOAD_COVER_DIR, ['jpg','jpeg','png','webp']);
            if ($newCover) {
                if ($coverName && file_exists(UPLOAD_COVER_DIR . $coverName)) @unlink(UPLOAD_COVER_DIR . $coverName);
                $coverName = $newCover;
            }
            if ($isDigital) {
                $newEbook = handle_upload('ebook_file', UPLOAD_BOOK_DIR, ['pdf','epub']);
                if ($newEbook) {
                    if ($ebookName && file_exists(UPLOAD_BOOK_DIR . $ebookName)) @unlink(UPLOAD_BOOK_DIR . $ebookName);
                    $ebookName = $newEbook;
                }
            }
        } catch (RuntimeException $e) {
            $errors[] = $e->getMessage();
        }
    }

    if (!$errors) {
        $stmt = db()->prepare('UPDATE books SET title=?, author=?, description=?, price=?, stock=?, category_id=?, cover_image=?, ebook_file=?, is_digital=? WHERE id=?');
        $stmt->execute([$title, $author, $description, $price, $isDigital ? 0 : $stock, $categoryId, $coverName, $ebookName, $isDigital, $id]);
        flash('success', 'Book updated successfully.');
        redirect('/admin/books_manage.php');
    }
    $book = array_merge($book, compact('title','author','description','price','stock','categoryId','isDigital'));
}
?>
<h2>Edit Book</h2>
<?php foreach ($errors as $err): ?><div class="error-box"><?= e($err) ?></div><?php endforeach; ?>

<form method="post" action="" enctype="multipart/form-data" style="max-width:600px;">
  <?= csrf_field() ?>
  <label>Title</label>
  <input type="text" name="title" required value="<?= e($book['title']) ?>">

  <label>Author</label>
  <input type="text" name="author" required value="<?= e($book['author']) ?>">

  <label>Description</label>
  <textarea name="description"><?= e($book['description']) ?></textarea>

  <label>Price (<?= CURRENCY ?>)</label>
  <input type="number" step="0.01" name="price" required value="<?= e($book['price']) ?>">

  <label>Category</label>
  <select name="category_id">
    <option value="0">— None —</option>
    <?php foreach ($categories as $c): ?>
      <option value="<?= $c['id'] ?>" <?= $book['category_id'] == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
    <?php endforeach; ?>
  </select>

  <label><input type="checkbox" name="is_digital" id="is_digital" <?= $book['is_digital'] ? 'checked' : '' ?> style="width:auto;display:inline-block;" onchange="document.getElementById('stock_field').style.display=this.checked?'none':'block';document.getElementById('ebook_field').style.display=this.checked?'block':'none';"> This is a digital eBook</label>

  <div id="stock_field" style="<?= $book['is_digital'] ? 'display:none;' : '' ?>">
    <label>Stock Quantity</label>
    <input type="number" name="stock" value="<?= e($book['stock']) ?>">
  </div>

  <div id="ebook_field" style="<?= $book['is_digital'] ? '' : 'display:none;' ?>">
    <label>Replace eBook File (leave blank to keep current)</label>
    <input type="file" name="ebook_file" accept=".pdf,.epub">
    <?php if ($book['ebook_file']): ?><p style="font-size:.85rem;color:#777;">Current: <?= e($book['ebook_file']) ?></p><?php endif; ?>
  </div>

  <label>Replace Cover Image (leave blank to keep current)</label>
  <input type="file" name="cover_image" accept=".jpg,.jpeg,.png,.webp">
  <?php if ($book['cover_image']): ?>
    <img src="<?= SITE_URL ?>/uploads/covers/<?= e($book['cover_image']) ?>" style="width:80px;margin-top:8px;border-radius:6px;">
  <?php endif; ?>

  <div class="form-actions">
    <button type="submit" class="btn btn-primary">Update Book</button>
  </div>
</form>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
