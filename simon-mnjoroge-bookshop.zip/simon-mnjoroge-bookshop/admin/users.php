<?php
$pageTitle = 'Users';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $userId = (int)$_POST['user_id'];
    $action = $_POST['action'];

    if ($userId === current_user()['id']) {
        flash('error', 'You cannot modify your own account here.');
        redirect('/admin/users.php');
    }

    if ($action === 'toggle_role') {
        db()->prepare("UPDATE users SET role = IF(role='admin','customer','admin') WHERE id = ?")->execute([$userId]);
    } elseif ($action === 'toggle_status') {
        db()->prepare("UPDATE users SET status = IF(status='active','suspended','active') WHERE id = ?")->execute([$userId]);
    }
    flash('success', 'User updated.');
    redirect('/admin/users.php');
}

$users = db()->query('SELECT * FROM users ORDER BY created_at DESC')->fetchAll();
?>
<h2>Users</h2>
<?php if ($msg = flash('success')): ?><div class="success-box"><?= e($msg) ?></div><?php endif; ?>
<?php if ($msg = flash('error')): ?><div class="error-box"><?= e($msg) ?></div><?php endif; ?>

<table>
  <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($users as $u): ?>
    <tr>
      <td><?= e($u['full_name']) ?></td>
      <td><?= e($u['email']) ?></td>
      <td><?= e(ucfirst($u['role'])) ?></td>
      <td><span class="badge <?= $u['status']==='active' ? 'badge-paid' : 'badge-failed' ?>"><?= e(ucfirst($u['status'])) ?></span></td>
      <td><?= e(date('M j, Y', strtotime($u['created_at']))) ?></td>
      <td style="white-space:nowrap;">
        <?php if ($u['id'] !== current_user()['id']): ?>
          <form method="post" style="display:inline;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="toggle_role">
            <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
            <button type="submit" class="btn btn-outline btn-small" style="color:var(--brand);border-color:var(--brand);">Toggle Admin</button>
          </form>
          <form method="post" style="display:inline;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="toggle_status">
            <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
            <button type="submit" class="btn btn-danger btn-small"><?= $u['status']==='active' ? 'Suspend' : 'Reactivate' ?></button>
          </form>
        <?php else: ?>
          <em style="color:#999;">You</em>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
