<?php
require_once __DIR__ . '/../../includes/functions.php';
require_admin();
$pageTitle = ($pageTitle ?? 'Admin') . ' — Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle) ?> | <?= e(SITE_NAME) ?></title>
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>
<?php include __DIR__ . '/../../includes/navbar.php'; ?>
<div class="admin-wrap">
  <aside class="admin-sidebar">
    <h3 style="color:#fff;">Admin Panel</h3>
    <a href="<?= SITE_URL ?>/admin/index.php">Dashboard</a>
    <a href="<?= SITE_URL ?>/admin/books_manage.php">Manage Books</a>
    <a href="<?= SITE_URL ?>/admin/book_add.php">Add New Book</a>
    <a href="<?= SITE_URL ?>/admin/orders.php">Orders</a>
    <a href="<?= SITE_URL ?>/admin/users.php">Users</a>
    <a href="<?= SITE_URL ?>/index.php">&larr; Back to Site</a>
  </aside>
  <div class="admin-content">
