<?php
$pageTitle = 'Manage Books';
require_once __DIR__ . '/includes/admin_header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    verify_csrf();
    $id = (int)$_POST['book_id'];
    $stmt = db()->prepare('SELECT cover_image, ebook_file FROM books WHERE id = ?');
    $stmt->execute([$id]);
    if ($row = $stmt->fetch()) {
        if ($row['cover_image'] && file_exists(UPLOAD_COVER_DIR . $row['cover_image'])) {
            @unlink(UPLOAD_COVER_DIR . $row['cover_image']);
        }
        if ($row['ebook_file'] && file_exists(UPLOAD_BOOK_DIR . $row['ebook_file'])) {
            @unlink(UPLOAD_BOOK_DIR . $row['ebook_file']);
        }
    }
    db()->prepare('DELETE FROM books WHERE id = ?')->execute([$id]);
    flash('success', 'Book deleted.');
    redirect('/admin/books_manage.php');
}

$books = db()->query('SELECT b.*, c.name AS category_name FROM books b LEFT JOIN categories c ON b.category_id=c.id ORDER BY b.created_at DESC')->fetchAll();
?>
<h2>Manage Books</h2>
<?php if ($msg = flash('success')): ?><div class="success-box"><?= e($msg) ?></div><?php endif; ?>
<p><a href="<?= SITE_URL ?>/admin/book_add.php" class="btn btn-primary">+ Add New Book</a></p>

<table>
  <thead><tr><th>Cover</th><th>Title</th><th>Author</th><th>Category</th><th>Price</th><th>Stock</th><th>Type</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($books as $b): ?>
    <tr>
      <td><?php if ($b['cover_image']): ?><img src="<?= SITE_URL ?>/uploads/covers/<?= e($b['cover_image']) ?>" style="width:40px;height:56px;object-fit:cover;border-radius:4px;"><?php endif; ?></td>
      <td><?= e($b['title']) ?></td>
      <td><?= e($b['author']) ?></td>
      <td><?= e($b['category_name'] ?? '—') ?></td>
      <td><?= format_money($b['price']) ?></td>
      <td><?= $b['is_digital'] ? 'Digital' : (int)$b['stock'] ?></td>
      <td><?= $b['is_digital'] ? 'eBook' : 'Physical' ?></td>
      <td style="white-space:nowrap;">
        <a href="<?= SITE_URL ?>/admin/book_edit.php?id=<?= (int)$b['id'] ?>" class="btn btn-outline btn-small" style="color:var(--brand);border-color:var(--brand);">Edit</a>
        <form method="post" style="display:inline;" onsubmit="return confirm('Delete this book permanently?');">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="book_id" value="<?= (int)$b['id'] ?>">
          <button type="submit" class="btn btn-danger btn-small">Delete</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
