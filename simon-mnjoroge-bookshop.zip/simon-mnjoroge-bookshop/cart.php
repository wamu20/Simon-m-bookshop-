<?php
require_once __DIR__ . '/includes/functions.php';
require_login();
$pageTitle = 'Your Cart';

$userId = current_user()['id'];
$stmt = db()->prepare('SELECT ci.quantity, b.* FROM cart_items ci JOIN books b ON ci.book_id = b.id WHERE ci.user_id = ? ORDER BY ci.created_at DESC');
$stmt->execute([$userId]);
$items = $stmt->fetchAll();

$total = 0;
foreach ($items as $it) $total += $it['price'] * $it['quantity'];

include __DIR__ . '/includes/header.php';
?>
<div class="container section">
  <h2>Your Cart</h2>
  <?php if ($msg = flash('success')): ?><div class="success-box"><?= e($msg) ?></div><?php endif; ?>

  <?php if (!$items): ?>
    <p>Your cart is empty. <a href="<?= SITE_URL ?>/books.php">Browse books</a> to get started.</p>
  <?php else: ?>
    <table>
      <thead><tr><th>Book</th><th>Price</th><th>Quantity</th><th>Subtotal</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($items as $it): ?>
        <tr>
          <td><a href="<?= SITE_URL ?>/book.php?id=<?= (int)$it['id'] ?>"><?= e($it['title']) ?></a></td>
          <td><?= format_money($it['price']) ?></td>
          <td>
            <form method="post" action="<?= SITE_URL ?>/cart_action.php" style="display:flex;gap:6px;">
              <?= csrf_field() ?>
              <input type="hidden" name="book_id" value="<?= (int)$it['id'] ?>">
              <input type="hidden" name="action" value="update">
              <input type="number" name="quantity" value="<?= (int)$it['quantity'] ?>" min="0" <?= $it['is_digital'] ? 'max="1"' : '' ?> style="width:70px;">
              <button type="submit" class="btn btn-outline btn-small" style="color:var(--brand);border-color:var(--brand);">Update</button>
            </form>
          </td>
          <td><?= format_money($it['price'] * $it['quantity']) ?></td>
          <td>
            <form method="post" action="<?= SITE_URL ?>/cart_action.php">
              <?= csrf_field() ?>
              <input type="hidden" name="book_id" value="<?= (int)$it['id'] ?>">
              <input type="hidden" name="action" value="remove">
              <button type="submit" class="btn btn-danger btn-small">Remove</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <div style="text-align:right;margin-top:20px;font-size:1.2rem;">
      <strong>Total: <?= format_money($total) ?></strong>
    </div>
    <div style="text-align:right;margin-top:14px;">
      <a href="<?= SITE_URL ?>/checkout.php" class="btn btn-primary">Proceed to Checkout</a>
    </div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
