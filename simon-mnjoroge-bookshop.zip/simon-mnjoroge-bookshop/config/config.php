<?php
/**
 * Simon Mnjoroge Bookshop — Global configuration
 * "A Haven of Knowledge"
 */

// ---- Database credentials -------------------------------------------------
define('DB_HOST', 'localhost');
define('DB_NAME', 'smb_bookshop');
define('DB_USER', 'root');
define('DB_PASS', '');

// ---- Site info --------------------------------------------------------
define('SITE_NAME', 'Simon Mnjoroge Bookshop');
define('SITE_MOTTO', 'A Haven of Knowledge');
define('SITE_MISSION', 'To be the leading wholistic partner for individuals able to face life\'s challenges.');
define('SITE_URL', 'http://localhost/simon-mnjoroge-bookshop'); // change to your live domain, no trailing slash
define('CURRENCY', 'KES');           // display currency code
define('CURRENCY_SYMBOL', 'KSh');

// ---- Uploads ------------------------------------------------------------
define('UPLOAD_COVER_DIR', __DIR__ . '/../uploads/covers/');
define('UPLOAD_BOOK_DIR', __DIR__ . '/../uploads/books/');
define('MAX_UPLOAD_BYTES', 20 * 1024 * 1024); // 20MB

// ---- Stripe (get keys from https://dashboard.stripe.com/apikeys) --------
define('STRIPE_SECRET_KEY', 'sk_test_REPLACE_ME');
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_REPLACE_ME');
define('STRIPE_WEBHOOK_SECRET', 'whsec_REPLACE_ME');

// ---- M-Pesa Daraja (get from https://developer.safaricom.co.ke) ---------
define('MPESA_ENV', 'sandbox');           // 'sandbox' or 'production'
define('MPESA_CONSUMER_KEY', 'REPLACE_ME');
define('MPESA_CONSUMER_SECRET', 'REPLACE_ME');
define('MPESA_SHORTCODE', '174379');       // sandbox default paybill/till
define('MPESA_PASSKEY', 'REPLACE_ME');
define('MPESA_CALLBACK_URL', SITE_URL . '/payment/mpesa_callback.php');

// ---- Session ------------------------------------------------------------
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---- Error display (turn off in production) ------------------------------
error_reporting(E_ALL);
ini_set('display_errors', '0'); // keep 0 on a live site; errors are logged instead
ini_set('log_errors', '1');

date_default_timezone_set('Africa/Nairobi');
