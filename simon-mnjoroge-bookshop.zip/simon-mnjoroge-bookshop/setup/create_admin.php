<?php
/**
 * Run this ONCE in your browser after importing sql/schema.sql to create
 * your first admin account, then DELETE this file (or move it outside
 * the web root) for security.
 */
require_once __DIR__ . '/../config/db.php';

$done = false;
$error = '';

// Refuse to run if an admin already exists, to prevent this file being
// abused to create extra admin accounts if someone forgets to delete it.
$existingAdmin = db()->query("SELECT COUNT(*) c FROM users WHERE role='admin'")->fetch()['c'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $existingAdmin == 0) {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($name && filter_var($email, FILTER_VALIDATE_EMAIL) && strlen($password) >= 8) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = db()->prepare('INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, "admin")');
        $stmt->execute([$name, $email, $hash]);
        $done = true;
    } else {
        $error = 'Please provide a name, a valid email, and a password of at least 8 characters.';
    }
}
?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Create Admin Account</title>
<style>body{font-family:Arial;max-width:420px;margin:60px auto;padding:0 20px;}
input{width:100%;padding:8px;margin:6px 0 14px;box-sizing:border-box;}
button{padding:10px 20px;background:#0f6b52;color:#fff;border:0;border-radius:6px;cursor:pointer;}
.warn{background:#fdecea;color:#b3261e;padding:10px;border-radius:6px;}
.ok{background:#e6f4ea;color:#1e7e34;padding:10px;border-radius:6px;}
</style></head><body>
<h2>Create Admin Account</h2>

<?php if ($existingAdmin > 0): ?>
  <p class="warn">An admin account already exists. For security, this setup script will not create another one.
  Please <strong>delete setup/create_admin.php</strong> now. To add more admins, promote an existing user from
  the Admin &rarr; Users panel instead.</p>
<?php elseif ($done): ?>
  <p class="ok">Admin account created! You can now <a href="../login.php">log in</a>.<br>
  <strong>Important:</strong> delete this file (setup/create_admin.php) right now.</p>
<?php else: ?>
  <?php if ($error): ?><p class="warn"><?= htmlspecialchars($error) ?></p><?php endif; ?>
  <form method="post">
    <label>Full Name</label><input type="text" name="name" required>
    <label>Email</label><input type="email" name="email" required>
    <label>Password (min 8 characters)</label><input type="password" name="password" required minlength="8">
    <button type="submit">Create Admin</button>
  </form>
<?php endif; ?>
</body></html>
