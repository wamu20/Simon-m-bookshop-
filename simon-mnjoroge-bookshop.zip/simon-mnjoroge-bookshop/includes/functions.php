<?php
require_once __DIR__ . '/../config/db.php';

// ---------------------------------------------------------------------
// Security / sanitation helpers
// ---------------------------------------------------------------------
function e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function clean_input($value): string
{
    return trim(strip_tags($value ?? ''));
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!$token || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(403);
        die('Invalid or expired form submission. Please go back and try again.');
    }
}

// ---------------------------------------------------------------------
// Auth helpers
// ---------------------------------------------------------------------
function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function is_logged_in(): bool
{
    return isset($_SESSION['user']);
}

function is_admin(): bool
{
    return is_logged_in() && $_SESSION['user']['role'] === 'admin';
}

function require_login(): void
{
    if (!is_logged_in()) {
        redirect('/login.php?next=' . urlencode($_SERVER['REQUEST_URI']));
    }
}

function require_admin(): void
{
    require_login();
    if (!is_admin()) {
        http_response_code(403);
        die('Access denied: admin privileges required.');
    }
}

// ---------------------------------------------------------------------
// Navigation / flash messages
// ---------------------------------------------------------------------
function redirect(string $path): void
{
    header('Location: ' . SITE_URL . $path);
    exit;
}

function flash(string $key, ?string $message = null)
{
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return null;
    }
    if (!empty($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return null;
}

// ---------------------------------------------------------------------
// Commerce helpers
// ---------------------------------------------------------------------
function format_money(float $amount): string
{
    return CURRENCY_SYMBOL . ' ' . number_format($amount, 2);
}

function cart_count(): int
{
    if (!is_logged_in()) return 0;
    $stmt = db()->prepare('SELECT COALESCE(SUM(quantity),0) AS c FROM cart_items WHERE user_id = ?');
    $stmt->execute([$_SESSION['user']['id']]);
    return (int) $stmt->fetch()['c'];
}

// ---------------------------------------------------------------------
// File upload helper (covers + optional ebook files)
// ---------------------------------------------------------------------
function handle_upload(string $inputName, string $destDir, array $allowedExt): ?string
{
    if (empty($_FILES[$inputName]) || $_FILES[$inputName]['error'] === UPLOAD_ERR_NO_FILE) {
        return null; // nothing uploaded, not an error
    }
    $file = $_FILES[$inputName];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Upload error code: ' . $file['error']);
    }
    if ($file['size'] > MAX_UPLOAD_BYTES) {
        throw new RuntimeException('File is too large. Max allowed is ' . (MAX_UPLOAD_BYTES / 1024 / 1024) . 'MB.');
    }
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExt, true)) {
        throw new RuntimeException('File type .' . $ext . ' is not allowed.');
    }
    if (!is_dir($destDir)) {
        mkdir($destDir, 0755, true);
    }
    $safeName = bin2hex(random_bytes(12)) . '.' . $ext;
    $destPath = $destDir . $safeName;
    if (!move_uploaded_file($file['tmp_name'], $destPath)) {
        throw new RuntimeException('Failed to save uploaded file.');
    }
    return $safeName;
}
