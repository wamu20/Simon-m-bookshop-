<nav class="navbar">
  <div class="inner">
    <a href="<?= SITE_URL ?>/index.php" class="brand">
      <strong><?= e(SITE_NAME) ?></strong>
      <span><?= e(SITE_MOTTO) ?></span>
    </a>
    <div class="nav-links">
      <a href="<?= SITE_URL ?>/index.php">Home</a>
      <a href="<?= SITE_URL ?>/books.php">Books</a>
      <a href="<?= SITE_URL ?>/about.php">About</a>
      <a href="<?= SITE_URL ?>/contact.php">Contact</a>
      <?php if (is_logged_in()): ?>
        <a href="<?= SITE_URL ?>/cart.php">Cart<?php $c = cart_count(); if ($c > 0): ?><span class="cart-badge"><?= (int)$c ?></span><?php endif; ?></a>
        <a href="<?= SITE_URL ?>/orders.php">My Orders</a>
        <?php if (is_admin()): ?>
          <a href="<?= SITE_URL ?>/admin/index.php">Admin</a>
        <?php endif; ?>
        <a href="<?= SITE_URL ?>/logout.php">Logout (<?= e(explode(' ', current_user()['full_name'])[0]) ?>)</a>
      <?php else: ?>
        <a href="<?= SITE_URL ?>/login.php">Login</a>
        <a href="<?= SITE_URL ?>/register.php">Register</a>
      <?php endif; ?>
    </div>
  </div>
</nav>
