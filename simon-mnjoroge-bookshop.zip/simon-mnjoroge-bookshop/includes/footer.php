</main>
<footer>
  <div class="motto">"<?= e(SITE_MOTTO) ?>"</div>
  <div>&copy; <?= date('Y') ?> <?= e(SITE_NAME) ?>. All rights reserved.</div>
</footer>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
