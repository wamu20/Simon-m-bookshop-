<?php
require_once __DIR__ . '/includes/functions.php';
$pageTitle = 'Books';

$search = clean_input($_GET['q'] ?? '');
$catId  = (int)($_GET['category'] ?? 0);

$sql = 'SELECT * FROM books WHERE 1=1';
$params = [];
if ($search !== '') {
    $sql .= ' AND (title LIKE ? OR author LIKE ?)';
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($catId > 0) {
    $sql .= ' AND category_id = ?';
    $params[] = $catId;
}
$sql .= ' ORDER BY created_at DESC';
$stmt = db()->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll();

$categories = db()->query('SELECT * FROM categories ORDER BY name')->fetchAll();

include __DIR__ . '/includes/header.php';
?>
<div class="container section">
  <h2>Our Collection</h2>
  <form method="get" action="" style="display:flex;gap:10px;margin-bottom:24px;flex-wrap:wrap;">
    <input type="text" name="q" placeholder="Search title or author..." value="<?= e($search) ?>" style="flex:1;min-width:200px;">
    <select name="category">
      <option value="0">All Categories</option>
      <?php foreach ($categories as $c): ?>
        <option value="<?= $c['id'] ?>" <?= $catId === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn btn-primary">Search</button>
  </form>

  <?php if (!$books): ?>
    <p>No books matched your search.</p>
  <?php else: ?>
    <div class="book-grid">
      <?php foreach ($books as $book): ?>
        <a class="book-card" href="<?= SITE_URL ?>/book.php?id=<?= (int)$book['id'] ?>">
          <div class="book-cover">
            <?php if ($book['cover_image']): ?>
              <img src="<?= SITE_URL ?>/uploads/covers/<?= e($book['cover_image']) ?>" alt="<?= e($book['title']) ?>">
            <?php else: ?>
              <span style="color:#aaa;">No cover</span>
            <?php endif; ?>
          </div>
          <div class="book-info">
            <h3><?= e($book['title']) ?></h3>
            <div class="author">by <?= e($book['author']) ?></div>
            <div class="price"><?= format_money($book['price']) ?></div>
            <?php if ($book['stock'] <= 0 && !$book['is_digital']): ?>
              <div style="color:#b3261e;font-size:.8rem;">Out of stock</div>
            <?php endif; ?>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
