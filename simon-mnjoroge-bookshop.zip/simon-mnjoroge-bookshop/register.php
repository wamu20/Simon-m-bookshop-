<?php
require_once __DIR__ . '/includes/functions.php';
$pageTitle = 'Create Account';

if (is_logged_in()) redirect('/index.php');

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $fullName = clean_input($_POST['full_name'] ?? '');
    $email    = strtolower(clean_input($_POST['email'] ?? ''));
    $phone    = clean_input($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if ($fullName === '') $errors[] = 'Full name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid email is required.';
    if (strlen($password) < 8) $errors[] = 'Password must be at least 8 characters.';
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';

    if (!$errors) {
        $stmt = db()->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = 'An account with that email already exists.';
        }
    }

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = db()->prepare('INSERT INTO users (full_name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, "customer")');
        $stmt->execute([$fullName, $email, $phone, $hash]);

        $userId = (int) db()->lastInsertId();
        $_SESSION['user'] = [
            'id' => $userId,
            'full_name' => $fullName,
            'email' => $email,
            'role' => 'customer',
        ];
        flash('success', 'Welcome to ' . SITE_NAME . '! Your account has been created.');
        redirect('/index.php');
    }
}

include __DIR__ . '/includes/header.php';
?>
<div class="container">
  <div class="form-box">
    <h2>Create Your Account</h2>
    <?php foreach ($errors as $err): ?>
      <div class="error-box"><?= e($err) ?></div>
    <?php endforeach; ?>
    <form method="post" action="">
      <?= csrf_field() ?>
      <label>Full Name</label>
      <input type="text" name="full_name" required value="<?= e($_POST['full_name'] ?? '') ?>">

      <label>Email</label>
      <input type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>">

      <label>Phone (optional)</label>
      <input type="tel" name="phone" value="<?= e($_POST['phone'] ?? '') ?>">

      <label>Password</label>
      <input type="password" name="password" required minlength="8">

      <label>Confirm Password</label>
      <input type="password" name="confirm_password" required minlength="8">

      <div class="form-actions">
        <button type="submit" class="btn btn-primary" style="width:100%;">Register</button>
      </div>
    </form>
    <p style="text-align:center;margin-top:16px;">Already have an account? <a href="<?= SITE_URL ?>/login.php">Log in</a></p>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
