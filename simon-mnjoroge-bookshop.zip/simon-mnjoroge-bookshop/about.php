<?php
require_once __DIR__ . '/includes/functions.php';
$pageTitle = 'About Us';
include __DIR__ . '/includes/header.php';
?>
<div class="container section">
  <h2>About <?= e(SITE_NAME) ?></h2>
  <p style="font-size:1.2rem;font-style:italic;color:var(--brand);">"<?= e(SITE_MOTTO) ?>"</p>
  <p><?= e(SITE_NAME) ?> is a hub for book lovers and lifelong learners — a place to discover
     fiction, non-fiction, business, spiritual, and self-development titles that inform,
     challenge, and inspire.</p>
  <h3>Our Mission</h3>
  <p><?= e(SITE_MISSION) ?></p>
  <p>Every book in our collection is chosen to help our readers grow — mentally, spiritually,
     and practically — so they can meet whatever life brings with wisdom and resilience.</p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
