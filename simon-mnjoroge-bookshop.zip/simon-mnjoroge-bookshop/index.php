<?php
require_once __DIR__ . '/includes/functions.php';
$pageTitle = 'Home';

$stmt = db()->query('SELECT * FROM books ORDER BY created_at DESC LIMIT 8');
$featured = $stmt->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<section class="hero">
  <h1><?= e(SITE_NAME) ?></h1>
  <div class="motto">"<?= e(SITE_MOTTO) ?>"</div>
  <p class="mission"><?= e(SITE_MISSION) ?></p>
  <a href="<?= SITE_URL ?>/books.php" class="btn btn-primary">Browse Books</a>
  <a href="<?= SITE_URL ?>/register.php" class="btn btn-outline">Join Us</a>
</section>

<div class="container section">
  <h2>Featured Books</h2>
  <?php if (!$featured): ?>
    <p>No books available yet. Please check back soon.</p>
  <?php else: ?>
    <div class="book-grid">
      <?php foreach ($featured as $book): ?>
        <a class="book-card" href="<?= SITE_URL ?>/book.php?id=<?= (int)$book['id'] ?>">
          <div class="book-cover">
            <?php if ($book['cover_image']): ?>
              <img src="<?= SITE_URL ?>/uploads/covers/<?= e($book['cover_image']) ?>" alt="<?= e($book['title']) ?>">
            <?php else: ?>
              <span style="color:#aaa;">No cover</span>
            <?php endif; ?>
          </div>
          <div class="book-info">
            <h3><?= e($book['title']) ?></h3>
            <div class="author">by <?= e($book['author']) ?></div>
            <div class="price"><?= format_money($book['price']) ?></div>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
