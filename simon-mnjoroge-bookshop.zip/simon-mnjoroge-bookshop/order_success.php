<?php
require_once __DIR__ . '/includes/functions.php';
require_login();
$pageTitle = 'Order Confirmation';

$orderId = (int)($_GET['order_id'] ?? 0);
$userId = current_user()['id'];

$stmt = db()->prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?');
$stmt->execute([$orderId, $userId]);
$order = $stmt->fetch();

if (!$order) {
    redirect('/orders.php');
}

$itemsStmt = db()->prepare('SELECT * FROM order_items WHERE order_id = ?');
$itemsStmt->execute([$orderId]);
$items = $itemsStmt->fetchAll();

include __DIR__ . '/includes/header.php';
?>
<div class="container section" style="text-align:center;">
  <h2>Thank You!</h2>
  <p>Your order <strong>#<?= $orderId ?></strong> has been placed.</p>
  <p>Status: <span class="badge badge-<?= e($order['status']) ?>"><?= e(ucfirst($order['status'])) ?></span></p>
  <?php if ($order['payment_method'] !== 'cod' && $order['status'] === 'pending'): ?>
    <p style="color:#777;">We're confirming your payment — this page will show "Paid" once confirmed. Check <a href="<?= SITE_URL ?>/orders.php">My Orders</a> for the latest status.</p>
  <?php endif; ?>

  <table style="max-width:500px;margin:20px auto;text-align:left;">
    <thead><tr><th>Book</th><th>Qty</th><th>Price</th></tr></thead>
    <tbody>
    <?php foreach ($items as $it): ?>
      <tr><td><?= e($it['title_snapshot']) ?></td><td><?= (int)$it['quantity'] ?></td><td><?= format_money($it['price']) ?></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <p style="font-size:1.2rem;"><strong>Total: <?= format_money($order['total_amount']) ?></strong></p>
  <a href="<?= SITE_URL ?>/books.php" class="btn btn-primary">Continue Shopping</a>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
