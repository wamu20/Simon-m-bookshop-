<?php
require_once __DIR__ . '/includes/functions.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT b.*, c.name AS category_name FROM books b LEFT JOIN categories c ON b.category_id = c.id WHERE b.id = ?');
$stmt->execute([$id]);
$book = $stmt->fetch();

if (!$book) {
    http_response_code(404);
    $pageTitle = 'Book Not Found';
    include __DIR__ . '/includes/header.php';
    echo '<div class="container section"><h2>Book Not Found</h2><p>That book does not exist or has been removed.</p></div>';
    include __DIR__ . '/includes/footer.php';
    exit;
}

$pageTitle = $book['title'];
include __DIR__ . '/includes/header.php';
?>
<div class="container section">
  <div style="display:flex;gap:36px;flex-wrap:wrap;">
    <div style="flex:0 0 280px;">
      <div class="book-cover" style="height:380px;border-radius:10px;">
        <?php if ($book['cover_image']): ?>
          <img src="<?= SITE_URL ?>/uploads/covers/<?= e($book['cover_image']) ?>" alt="<?= e($book['title']) ?>">
        <?php else: ?>
          <span style="color:#aaa;">No cover</span>
        <?php endif; ?>
      </div>
    </div>
    <div style="flex:1;min-width:280px;">
      <h1><?= e($book['title']) ?></h1>
      <p style="color:#777;">by <?= e($book['author']) ?><?php if ($book['category_name']): ?> &middot; <?= e($book['category_name']) ?><?php endif; ?></p>
      <p style="font-size:1.4rem;font-weight:700;color:var(--brand);"><?= format_money($book['price']) ?></p>
      <p><?= nl2br(e($book['description'])) ?></p>

      <?php if ($book['is_digital']): ?>
        <p style="color:#0f6b52;">📘 Digital / eBook — available instantly after purchase.</p>
      <?php elseif ($book['stock'] <= 0): ?>
        <p style="color:#b3261e;font-weight:600;">Out of stock</p>
      <?php else: ?>
        <p style="color:#555;font-size:.9rem;"><?= (int)$book['stock'] ?> in stock</p>
      <?php endif; ?>

      <?php if ($book['is_digital'] || $book['stock'] > 0): ?>
        <form method="post" action="<?= SITE_URL ?>/cart_action.php">
          <?= csrf_field() ?>
          <input type="hidden" name="book_id" value="<?= (int)$book['id'] ?>">
          <input type="hidden" name="action" value="add">
          <label style="display:inline-block;">Quantity</label>
          <input type="number" name="quantity" value="1" min="1" max="<?= $book['is_digital'] ? 1 : max(1,(int)$book['stock']) ?>" style="width:80px;display:inline-block;margin:0 10px;">
          <button type="submit" class="btn btn-primary">Add to Cart</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
