// Simon Mnjoroge Bookshop — small client-side UX helpers
document.addEventListener('DOMContentLoaded', function () {
  // Auto-dismiss flash messages after 5 seconds
  document.querySelectorAll('.success-box, .error-box').forEach(function (box) {
    setTimeout(function () {
      box.style.transition = 'opacity .5s';
      box.style.opacity = '0';
      setTimeout(function () { box.remove(); }, 500);
    }, 5000);
  });
});
