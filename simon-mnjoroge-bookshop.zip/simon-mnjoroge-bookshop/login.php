<?php
require_once __DIR__ . '/includes/functions.php';
$pageTitle = 'Login';

if (is_logged_in()) redirect('/index.php');

$errors = [];
$next = $_GET['next'] ?? '/index.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    // simple brute-force throttle
    $_SESSION['login_attempts'] = $_SESSION['login_attempts'] ?? 0;
    if ($_SESSION['login_attempts'] >= 8) {
        $errors[] = 'Too many failed attempts. Please wait a few minutes and try again.';
    } else {
        $email    = strtolower(clean_input($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';

        $stmt = db()->prepare('SELECT * FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            $_SESSION['login_attempts']++;
            $errors[] = 'Invalid email or password.';
        } elseif ($user['status'] === 'suspended') {
            $errors[] = 'This account has been suspended. Contact support.';
        } else {
            $_SESSION['login_attempts'] = 0;
            session_regenerate_id(true);
            $_SESSION['user'] = [
                'id' => $user['id'],
                'full_name' => $user['full_name'],
                'email' => $user['email'],
                'role' => $user['role'],
            ];
            $target = str_starts_with($next, '/') ? $next : '/index.php';
            redirect($target);
        }
    }
}

include __DIR__ . '/includes/header.php';
?>
<div class="container">
  <div class="form-box">
    <h2>Welcome Back</h2>
    <?php foreach ($errors as $err): ?>
      <div class="error-box"><?= e($err) ?></div>
    <?php endforeach; ?>
    <form method="post" action="<?= SITE_URL ?>/login.php?next=<?= e(urlencode($next)) ?>">
      <?= csrf_field() ?>
      <label>Email</label>
      <input type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>">

      <label>Password</label>
      <input type="password" name="password" required>

      <div class="form-actions">
        <button type="submit" class="btn btn-primary" style="width:100%;">Log In</button>
      </div>
    </form>
    <p style="text-align:center;margin-top:16px;">New here? <a href="<?= SITE_URL ?>/register.php">Create an account</a></p>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
