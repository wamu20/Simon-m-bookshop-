-- =====================================================
-- Simon Mnjoroge Bookshop — Database Schema
-- "A Haven of Knowledge"
-- =====================================================

CREATE DATABASE IF NOT EXISTS smb_bookshop CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smb_bookshop;

-- -----------------------------------------------------
-- Users (customers + admins)
-- -----------------------------------------------------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(30) DEFAULT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('customer','admin') NOT NULL DEFAULT 'customer',
    status ENUM('active','suspended') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- Categories
-- -----------------------------------------------------
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- Books
-- -----------------------------------------------------
CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(150) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    stock INT NOT NULL DEFAULT 0,
    category_id INT DEFAULT NULL,
    cover_image VARCHAR(255) DEFAULT NULL,      -- uploads/covers/xxx.jpg
    ebook_file VARCHAR(255) DEFAULT NULL,        -- uploads/books/xxx.pdf (optional digital copy)
    is_digital TINYINT(1) NOT NULL DEFAULT 0,
    uploaded_by INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- Cart items (persistent, per logged-in user)
-- -----------------------------------------------------
CREATE TABLE cart_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    book_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_user_book (user_id, book_id)
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- Orders
-- -----------------------------------------------------
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending','paid','failed','shipped','completed','cancelled') NOT NULL DEFAULT 'pending',
    payment_method ENUM('stripe','mpesa','cod') NOT NULL DEFAULT 'stripe',
    payment_reference VARCHAR(255) DEFAULT NULL,
    shipping_address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- Order items
-- -----------------------------------------------------
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    book_id INT NOT NULL,
    title_snapshot VARCHAR(255) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -----------------------------------------------------
-- Seed data
-- -----------------------------------------------------
INSERT INTO categories (name) VALUES
('Fiction'), ('Non-Fiction'), ('Self-Development'), ('Business'), ('Spirituality'), ('Children');

-- NOTE: No default admin is inserted here on purpose (a hard-coded password hash
-- shipped in a public schema file is a security risk). After importing this
-- schema, open /setup/create_admin.php in your browser ONCE to create your
-- admin account with a properly generated password hash, then delete that file.
