<?php
require_once __DIR__ . '/includes/functions.php';
require_login();
$pageTitle = 'My Orders';

$stmt = db()->prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC');
$stmt->execute([current_user()['id']]);
$orders = $stmt->fetchAll();

include __DIR__ . '/includes/header.php';
?>
<div class="container section">
  <h2>My Orders</h2>
  <?php if (!$orders): ?>
    <p>You haven't placed any orders yet. <a href="<?= SITE_URL ?>/books.php">Start shopping</a>.</p>
  <?php else: ?>
    <table>
      <thead><tr><th>Order #</th><th>Date</th><th>Total</th><th>Payment</th><th>Status</th></tr></thead>
      <tbody>
      <?php foreach ($orders as $o): ?>
        <tr>
          <td><a href="<?= SITE_URL ?>/order_success.php?order_id=<?= (int)$o['id'] ?>">#<?= (int)$o['id'] ?></a></td>
          <td><?= e(date('M j, Y g:ia', strtotime($o['created_at']))) ?></td>
          <td><?= format_money($o['total_amount']) ?></td>
          <td><?= e(strtoupper($o['payment_method'])) ?></td>
          <td><span class="badge badge-<?= e($o['status']) ?>"><?= e(ucfirst($o['status'])) ?></span></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
