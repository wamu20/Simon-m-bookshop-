<?php
/**
 * Creates a Stripe Checkout Session for a pending order and redirects the
 * customer to Stripe's hosted payment page. Uses raw cURL against the
 * Stripe REST API so no Composer/SDK install is required.
 */
require_once __DIR__ . '/../includes/functions.php';
require_login();

$orderId = (int)($_GET['order_id'] ?? 0);
$userId = current_user()['id'];

$stmt = db()->prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?');
$stmt->execute([$orderId, $userId]);
$order = $stmt->fetch();

if (!$order || $order['status'] !== 'pending') {
    die('Order not found or already processed.');
}

$itemsStmt = db()->prepare('SELECT * FROM order_items WHERE order_id = ?');
$itemsStmt->execute([$orderId]);
$items = $itemsStmt->fetchAll();

// Build Stripe line items (application/x-www-form-urlencoded, PHP array style)
$params = [
    'mode' => 'payment',
    'success_url' => SITE_URL . '/order_success.php?order_id=' . $orderId . '&session_id={CHECKOUT_SESSION_ID}',
    'cancel_url'  => SITE_URL . '/checkout.php',
    'client_reference_id' => (string)$orderId,
    'customer_email' => current_user()['email'],
];

$i = 0;
foreach ($items as $item) {
    $params['line_items'][$i]['price_data']['currency'] = strtolower(CURRENCY);
    $params['line_items'][$i]['price_data']['product_data']['name'] = $item['title_snapshot'];
    $params['line_items'][$i]['price_data']['unit_amount'] = (int) round($item['price'] * 100); // smallest currency unit
    $params['line_items'][$i]['quantity'] = (int) $item['quantity'];
    $i++;
}

$ch = curl_init('https://api.stripe.com/v1/checkout/sessions');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => http_build_query($params),
    CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . STRIPE_SECRET_KEY],
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$data = json_decode($response, true);

if ($httpCode !== 200 || empty($data['url'])) {
    error_log('Stripe session creation failed: ' . $response);
    die('Could not start payment. Please try again, or contact support if this persists. ' .
        'If you are the site owner: check that STRIPE_SECRET_KEY is set correctly in config/config.php.');
}

// Save the Stripe session id against the order for later verification
db()->prepare('UPDATE orders SET payment_reference = ? WHERE id = ?')->execute([$data['id'], $orderId]);

redirect_external($data['url']);

function redirect_external(string $url): void
{
    header('Location: ' . $url);
    exit;
}
