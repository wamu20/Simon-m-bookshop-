<?php
/**
 * Safaricom Daraja calls this URL automatically after the customer
 * approves/cancels the STK push. Must be a public HTTPS URL — set it
 * as MPESA_CALLBACK_URL in config/config.php.
 */
require_once __DIR__ . '/../config/db.php';

$raw = file_get_contents('php://input');
error_log('M-Pesa callback received: ' . $raw); // keep an audit trail

$data = json_decode($raw, true);
$callback = $data['Body']['stkCallback'] ?? null;

if ($callback) {
    $checkoutRequestId = $callback['CheckoutRequestID'] ?? '';
    $resultCode = $callback['ResultCode'] ?? 1;

    $stmt = db()->prepare('SELECT id FROM orders WHERE payment_reference = ?');
    $stmt->execute([$checkoutRequestId]);
    $order = $stmt->fetch();

    if ($order) {
        if ((int)$resultCode === 0) {
            // Success — pull out the M-Pesa receipt number for our records
            $receipt = null;
            foreach (($callback['CallbackMetadata']['Item'] ?? []) as $item) {
                if ($item['Name'] === 'MpesaReceiptNumber') $receipt = $item['Value'];
            }
            db()->prepare('UPDATE orders SET status = "paid", payment_reference = ? WHERE id = ?')
                ->execute([$receipt ?: $checkoutRequestId, $order['id']]);
        } else {
            db()->prepare('UPDATE orders SET status = "failed" WHERE id = ?')->execute([$order['id']]);
        }
    }
}

// Safaricom expects this exact acknowledgement
header('Content-Type: application/json');
echo json_encode(['ResultCode' => 0, 'ResultDesc' => 'Accepted']);
