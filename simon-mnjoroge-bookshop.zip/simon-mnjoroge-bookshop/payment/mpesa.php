<?php
/**
 * Initiates an M-Pesa STK Push ("Lipa na M-Pesa Online") prompt to the
 * customer's phone for a pending order, using Safaricom's Daraja API.
 *
 * Setup:
 *  1. Create an app at https://developer.safaricom.co.ke
 *  2. Fill in MPESA_* constants in config/config.php
 *  3. Set MPESA_CALLBACK_URL to a PUBLICLY reachable HTTPS URL
 *     pointing at payment/mpesa_callback.php (Safaricom cannot reach localhost).
 */
require_once __DIR__ . '/../includes/functions.php';
require_login();

$orderId = (int)($_GET['order_id'] ?? 0);
$phone   = preg_replace('/\D/', '', $_GET['phone'] ?? '');
$userId  = current_user()['id'];

$stmt = db()->prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?');
$stmt->execute([$orderId, $userId]);
$order = $stmt->fetch();

if (!$order || $order['status'] !== 'pending') {
    die('Order not found or already processed.');
}
if (!preg_match('/^2547\d{8}$/', $phone)) {
    die('Invalid phone number format. Expected 2547XXXXXXXX.');
}

$baseUrl = MPESA_ENV === 'production'
    ? 'https://api.safaricom.co.ke'
    : 'https://sandbox.safaricom.co.ke';

// ---- 1. Get OAuth access token -----------------------------------------
$credentials = base64_encode(MPESA_CONSUMER_KEY . ':' . MPESA_CONSUMER_SECRET);
$ch = curl_init($baseUrl . '/oauth/v1/generate?grant_type=client_credentials');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => ['Authorization: Basic ' . $credentials],
]);
$tokenResp = json_decode(curl_exec($ch), true);
curl_close($ch);

$accessToken = $tokenResp['access_token'] ?? null;
if (!$accessToken) {
    error_log('M-Pesa token request failed: ' . json_encode($tokenResp));
    die('Could not reach M-Pesa. Please try again shortly, or choose another payment method.');
}

// ---- 2. Trigger STK push -------------------------------------------------
$timestamp = date('YmdHis');
$password = base64_encode(MPESA_SHORTCODE . MPESA_PASSKEY . $timestamp);

$stkPayload = [
    'BusinessShortCode' => MPESA_SHORTCODE,
    'Password'          => $password,
    'Timestamp'         => $timestamp,
    'TransactionType'   => 'CustomerPayBillOnline',
    'Amount'            => (int) ceil($order['total_amount']), // M-Pesa needs whole numbers
    'PartyA'            => $phone,
    'PartyB'            => MPESA_SHORTCODE,
    'PhoneNumber'       => $phone,
    'CallBackURL'       => MPESA_CALLBACK_URL,
    'AccountReference'  => 'ORDER' . $orderId,
    'TransactionDesc'   => 'Payment for order #' . $orderId . ' - ' . SITE_NAME,
];

$ch = curl_init($baseUrl . '/mpesa/stkpush/v1/processrequest');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($stkPayload),
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $accessToken,
        'Content-Type: application/json',
    ],
]);
$stkResp = json_decode(curl_exec($ch), true);
curl_close($ch);

if (empty($stkResp['CheckoutRequestID'])) {
    error_log('M-Pesa STK push failed: ' . json_encode($stkResp));
    die('We could not send the M-Pesa prompt. Please try again, or choose another payment method.');
}

// Save the CheckoutRequestID so the callback can match it back to this order
db()->prepare('UPDATE orders SET payment_reference = ? WHERE id = ?')
   ->execute([$stkResp['CheckoutRequestID'], $orderId]);

$pageTitle = 'Complete M-Pesa Payment';
include __DIR__ . '/../includes/header.php';
?>
<div class="container section" style="text-align:center;">
  <h2>Check Your Phone</h2>
  <p>An M-Pesa payment prompt has been sent to <strong><?= e($phone) ?></strong>.</p>
  <p>Enter your M-Pesa PIN on your phone to complete payment of <?= format_money($order['total_amount']) ?> for order #<?= $orderId ?>.</p>
  <p style="color:#777;">This page will not auto-refresh — once you approve the payment on your phone,
     your order status will update automatically. You can check its status any time on
     <a href="<?= SITE_URL ?>/orders.php">My Orders</a>.</p>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
