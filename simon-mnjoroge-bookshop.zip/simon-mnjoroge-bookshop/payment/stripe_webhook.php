<?php
/**
 * Stripe webhook listener.
 * Configure this URL in your Stripe Dashboard > Developers > Webhooks:
 *   https://yourdomain.com/payment/stripe_webhook.php
 * Listen for event: checkout.session.completed
 *
 * This is the AUTHORITATIVE way payments get marked "paid" — never trust
 * the browser redirect (success_url) alone, since a user can navigate
 * there without actually paying.
 */
require_once __DIR__ . '/../config/db.php';

$payload = @file_get_contents('php://input');
$sigHeader = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

if (!verify_stripe_signature($payload, $sigHeader, STRIPE_WEBHOOK_SECRET)) {
    http_response_code(400);
    exit('Invalid signature');
}

$event = json_decode($payload, true);

if (($event['type'] ?? '') === 'checkout.session.completed') {
    $session = $event['data']['object'];
    $orderId = (int)($session['client_reference_id'] ?? 0);
    $sessionId = $session['id'];

    if ($orderId > 0) {
        $stmt = db()->prepare('UPDATE orders SET status = "paid", payment_reference = ? WHERE id = ? AND status = "pending"');
        $stmt->execute([$sessionId, $orderId]);
    }
}

http_response_code(200);
echo 'OK';

/**
 * Minimal Stripe webhook signature verification (no SDK dependency).
 * See: https://docs.stripe.com/webhooks#verify-manually
 */
function verify_stripe_signature(string $payload, string $sigHeader, string $secret): bool
{
    if (!$payload || !$sigHeader || !$secret) return false;

    $parts = [];
    foreach (explode(',', $sigHeader) as $pair) {
        [$k, $v] = array_pad(explode('=', $pair, 2), 2, '');
        $parts[$k] = $v;
    }
    if (empty($parts['t']) || empty($parts['v1'])) return false;

    $signedPayload = $parts['t'] . '.' . $payload;
    $expected = hash_hmac('sha256', $signedPayload, $secret);

    return hash_equals($expected, $parts['v1']);
}
