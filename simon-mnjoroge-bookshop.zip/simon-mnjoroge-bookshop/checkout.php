<?php
require_once __DIR__ . '/includes/functions.php';
require_login();
$pageTitle = 'Checkout';

$userId = current_user()['id'];
$stmt = db()->prepare('SELECT ci.quantity, b.* FROM cart_items ci JOIN books b ON ci.book_id = b.id WHERE ci.user_id = ?');
$stmt->execute([$userId]);
$items = $stmt->fetchAll();

if (!$items) {
    flash('error', 'Your cart is empty.');
    redirect('/cart.php');
}

$total = 0;
foreach ($items as $it) $total += $it['price'] * $it['quantity'];

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $address = clean_input($_POST['address'] ?? '');
    $method  = $_POST['payment_method'] ?? 'stripe';
    $phone   = clean_input($_POST['mpesa_phone'] ?? '');

    if ($address === '') $errors[] = 'Shipping / billing address is required.';
    if (!in_array($method, ['stripe', 'mpesa', 'cod'], true)) $errors[] = 'Invalid payment method.';
    if ($method === 'mpesa' && !preg_match('/^2547\d{8}$/', $phone)) {
        $errors[] = 'Enter a valid M-Pesa phone number in format 2547XXXXXXXX.';
    }

    // re-check stock for physical books
    if (!$errors) {
        foreach ($items as $it) {
            if (!$it['is_digital']) {
                $s = db()->prepare('SELECT stock FROM books WHERE id = ?');
                $s->execute([$it['id']]);
                $stock = (int)$s->fetch()['stock'];
                if ($stock < $it['quantity']) {
                    $errors[] = e($it['title']) . ' only has ' . $stock . ' left in stock.';
                }
            }
        }
    }

    if (!$errors) {
        db()->beginTransaction();
        try {
            $stmt = db()->prepare('INSERT INTO orders (user_id, total_amount, status, payment_method, shipping_address) VALUES (?, ?, "pending", ?, ?)');
            $stmt->execute([$userId, $total, $method, $address]);
            $orderId = (int) db()->lastInsertId();

            $itemStmt = db()->prepare('INSERT INTO order_items (order_id, book_id, title_snapshot, price, quantity) VALUES (?, ?, ?, ?, ?)');
            foreach ($items as $it) {
                $itemStmt->execute([$orderId, $it['id'], $it['title'], $it['price'], $it['quantity']]);
                if (!$it['is_digital']) {
                    db()->prepare('UPDATE books SET stock = stock - ? WHERE id = ?')->execute([$it['quantity'], $it['id']]);
                }
            }
            db()->commit();

            // clear cart
            db()->prepare('DELETE FROM cart_items WHERE user_id = ?')->execute([$userId]);

            if ($method === 'stripe') {
                redirect('/payment/stripe_checkout.php?order_id=' . $orderId);
            } elseif ($method === 'mpesa') {
                redirect('/payment/mpesa.php?order_id=' . $orderId . '&phone=' . urlencode($phone));
            } else {
                // Cash on delivery
                redirect('/order_success.php?order_id=' . $orderId);
            }
        } catch (Exception $e) {
            db()->rollBack();
            error_log('Checkout error: ' . $e->getMessage());
            $errors[] = 'Something went wrong while placing your order. Please try again.';
        }
    }
}

include __DIR__ . '/includes/header.php';
?>
<div class="container section">
  <h2>Checkout</h2>
  <?php foreach ($errors as $err): ?><div class="error-box"><?= e($err) ?></div><?php endforeach; ?>

  <div style="display:flex;gap:40px;flex-wrap:wrap;">
    <div style="flex:1;min-width:280px;">
      <table>
        <thead><tr><th>Book</th><th>Qty</th><th>Subtotal</th></tr></thead>
        <tbody>
        <?php foreach ($items as $it): ?>
          <tr><td><?= e($it['title']) ?></td><td><?= (int)$it['quantity'] ?></td><td><?= format_money($it['price'] * $it['quantity']) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <p style="text-align:right;font-size:1.2rem;margin-top:10px;"><strong>Total: <?= format_money($total) ?></strong></p>
    </div>

    <div style="flex:1;min-width:280px;">
      <form method="post" action="">
        <?= csrf_field() ?>
        <label>Shipping / Billing Address</label>
        <textarea name="address" required><?= e($_POST['address'] ?? '') ?></textarea>

        <label>Payment Method</label>
        <select name="payment_method" id="payment_method" onchange="document.getElementById('mpesa_field').style.display=this.value==='mpesa'?'block':'none';">
          <option value="stripe">Card / Stripe (Visa, Mastercard)</option>
          <option value="mpesa">M-Pesa</option>
          <option value="cod">Cash on Delivery</option>
        </select>

        <div id="mpesa_field" style="display:none;">
          <label>M-Pesa Phone (format 2547XXXXXXXX)</label>
          <input type="tel" name="mpesa_phone" placeholder="2547XXXXXXXX">
        </div>

        <div class="form-actions">
          <button type="submit" class="btn btn-primary" style="width:100%;">Place Order</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
