<?php
require_once __DIR__ . '/includes/functions.php';
$pageTitle = 'Contact Us';

$sent = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = clean_input($_POST['name'] ?? '');
    $email = clean_input($_POST['email'] ?? '');
    $message = clean_input($_POST['message'] ?? '');
    if ($name && filter_var($email, FILTER_VALIDATE_EMAIL) && $message) {
        // Simple built-in mail(); swap for a transactional email API (e.g. SendGrid, Mailgun)
        // in production for reliable delivery.
        $to = 'admin@simonmnjorogebookshop.com';
        $subject = 'New contact message from ' . $name;
        $body = "From: $name <$email>\n\n$message";
        @mail($to, $subject, $body, "From: no-reply@" . parse_url(SITE_URL, PHP_URL_HOST));
        $sent = true;
    }
}

include __DIR__ . '/includes/header.php';
?>
<div class="container">
  <div class="form-box">
    <h2>Contact Us</h2>
    <?php if ($sent): ?>
      <div class="success-box">Thanks for reaching out! We'll respond soon.</div>
    <?php endif; ?>
    <form method="post" action="">
      <?= csrf_field() ?>
      <label>Name</label>
      <input type="text" name="name" required>
      <label>Email</label>
      <input type="email" name="email" required>
      <label>Message</label>
      <textarea name="message" required></textarea>
      <div class="form-actions">
        <button type="submit" class="btn btn-primary" style="width:100%;">Send Message</button>
      </div>
    </form>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
