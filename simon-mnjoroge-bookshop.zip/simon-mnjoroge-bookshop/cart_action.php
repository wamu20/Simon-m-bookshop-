<?php
require_once __DIR__ . '/includes/functions.php';

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/books.php');
}
verify_csrf();

$userId = current_user()['id'];
$action = $_POST['action'] ?? '';
$bookId = (int)($_POST['book_id'] ?? 0);

if ($action === 'add') {
    $qty = max(1, (int)($_POST['quantity'] ?? 1));

    $stmt = db()->prepare('SELECT * FROM books WHERE id = ?');
    $stmt->execute([$bookId]);
    $book = $stmt->fetch();

    if (!$book) {
        flash('error', 'That book could not be found.');
        redirect('/books.php');
    }
    if (!$book['is_digital'] && $qty > $book['stock']) {
        $qty = max(1, (int)$book['stock']);
    }
    if ($book['is_digital']) $qty = 1;

    $stmt = db()->prepare('INSERT INTO cart_items (user_id, book_id, quantity) VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)');
    $stmt->execute([$userId, $bookId, $qty]);

    flash('success', e($book['title']) . ' added to your cart.');
    redirect('/cart.php');
}

if ($action === 'update') {
    $qty = max(0, (int)($_POST['quantity'] ?? 1));
    if ($qty === 0) {
        $stmt = db()->prepare('DELETE FROM cart_items WHERE user_id = ? AND book_id = ?');
        $stmt->execute([$userId, $bookId]);
    } else {
        $stmt = db()->prepare('UPDATE cart_items SET quantity = ? WHERE user_id = ? AND book_id = ?');
        $stmt->execute([$qty, $userId, $bookId]);
    }
    redirect('/cart.php');
}

if ($action === 'remove') {
    $stmt = db()->prepare('DELETE FROM cart_items WHERE user_id = ? AND book_id = ?');
    $stmt->execute([$userId, $bookId]);
    flash('success', 'Item removed from cart.');
    redirect('/cart.php');
}

redirect('/cart.php');
